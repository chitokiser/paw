// /geolocation/js/firebase.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.0.0/firebase-app.js";
import {
  getFirestore
} from "https://www.gstatic.com/firebasejs/10.0.0/firebase-firestore.js";
import {
  getAuth, signInAnonymously, onAuthStateChanged,
  setPersistence, browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/10.0.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCoeMQt7UZzNHFt22bnGv_-6g15BnwCEBA",
  authDomain: "puppi-d67a1.firebaseapp.com",
  projectId: "puppi-d67a1",
  storageBucket: "puppi-d67a1.appspot.com",
  messagingSenderId: "552900371836",
  appId: "1:552900371836:web:88fb6c6a7d3ca3c84530f9",
  measurementId: "G-9TZ81RW0PL"
};

export const app = initializeApp(firebaseConfig);
export const db  = getFirestore(app);
export const auth = getAuth(app);

// ✅ 로그인 지속성 + 익명 로그인 보장
export const authReady = (async () => {
  try { await setPersistence(auth, browserLocalPersistence); } catch(e) { /* dev 환경이면 무시 */ }
  // 이미 로그인되어 있으면 그대로, 아니면 익명 로그인
  const hasUser = !!auth.currentUser;
  if (!hasUser) {
    try { await signInAnonymously(auth); } catch (e) { console.warn('[auth] anon fail', e); }
  }
  // onAuthStateChanged로 최종 보장
  await new Promise((res) => {
    const unsub = onAuthStateChanged(auth, () => { unsub?.(); res(); });
  });
})();
