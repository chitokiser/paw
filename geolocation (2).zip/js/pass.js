// /geolocation/js/pass.js
export const CLAIM_PASS = 750206;